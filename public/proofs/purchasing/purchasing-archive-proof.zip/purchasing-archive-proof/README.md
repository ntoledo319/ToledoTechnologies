# Toledo purchasing archive — local proof

Inspectable proof of the processing core behind a proposed Stocky closeout product. **The fixture is entirely synthetic. No actual Stocky export has been inspected; actual Stocky format compatibility remains unverified.** This is not a live connector, inventory system, accounting product or complete commercial release.

## Run

Python 3.10+; standard library only. From this directory:

    python3 archive.py fixture.csv --output preview --synthetic
    python3 -m unittest -v

Open preview/index.html directly in a browser. No server is required. Search 00123 to see two POs/currencies, then filter USD, clear filters and search a nonexistent SKU. preview/report.json contains records, source references, rejections, duplicate exclusions and source SHA-256.

For a file already mapped to the documented schema:

    python3 archive.py mapped-input.csv --output private-output

The source CSV is read only. Existing index.html and report.json in the output directory are overwritten; use a fresh output directory per source. Do not expose genuine business files publicly.

## Exact input schema

Required header order:

    po_id,date,supplier,sku,currency,ordered_quantity,received_quantity,unit_cost

UTF-8 CSV, optional BOM, standard quoted/multiline CSV rules. PO, supplier and SKU are required strings, at most 500 characters. Leading-zero SKUs remain intact. Date must be a valid YYYY-MM-DD calendar date. Currency must be three uppercase letters; this proof does not validate against the ISO registry.

Quantities/cost are non-negative decimals, at most six fractional digits and 40 total characters. Scientific notation, NaN, negative values and nonnumeric text are rejected. Blank received quantity is unknown, never zero. Over-receipts are retained and labeled. Arithmetic uses 100-digit decimal precision, sufficient for documented input/row bounds.

Repeated PO IDs must agree on date/supplier/currency. Exact duplicate accepted rows are excluded and separately reported. This proof policy cannot determine whether identical real purchase lines are legitimate without their source IDs. No fuzzy matching is performed.

Limits: 10 MiB input / 50,000 data records. Unsupported headers and malformed CSV reject the full input; other invalid rows are reported and excluded from totals. Source references identify input record and physical ending line; multiline records may span lines.

## Calculations and expected fixture

Ordered line value = ordered quantity × unit cost, separately totaled by currency and supplier. It is **not actual spend, payments, received value, landed cost, tax, COGS or inventory valuation**.

Fixture: 8 input records, 4 accepted lines, 3 rejected lines, 1 excluded exact duplicate, 3 POs, 2 suppliers. Ordered line values total USD 95.00 and EUR 12.00. One accepted received quantity is unknown. Coverage equality only reconciles this input file; it cannot establish a complete export.

## Safety and scope

Source values are HTML-escaped. JSON embedded in HTML escapes angle brackets, ampersands and Unicode line separators. Source fields are never assigned to innerHTML. Search reads text from static rows. Formula-looking source strings remain text; the tool does not evaluate formulas or generate spreadsheet CSV exports. Original untrusted strings remain in report.json; do not execute them in downstream tooling.

Content security policy blocks network connections, external scripts and form submissions. The generated page has no external fonts, URLs, dependencies or uploads. SHA-256 fingerprints the input; it does not certify origin, completeness or legal admissibility. No missing field is inferred or fetched. Nothing modifies Shopify, Stocky, inventory or supplier records.

Production work still needs authorized real exports, stable line IDs, verified mapping rules, larger-data tests, operational support and independent browser/security review. Current verification is recorded separately; no accessibility certification is claimed.

