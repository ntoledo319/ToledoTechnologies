import csv, hashlib, io, json, re, unittest
from pathlib import Path
from archive import FIELDS, inspect_bytes, render, safe_json

BASE=Path(__file__).parent
def data(**changes):
    row=dict(zip(FIELDS,['PO-1','2026-08-01','Supplier','00123','USD','10','6','2.50']))
    row.update(changes)
    out=io.StringIO(newline='')
    writer=csv.DictWriter(out,fieldnames=FIELDS)
    writer.writeheader();writer.writerow(row)
    return out.getvalue().encode()

class ArchiveTest(unittest.TestCase):
    def test_fixture_totals(self):
        r=inspect_bytes((BASE/'fixture.csv').read_bytes())
        self.assertEqual(r['currency_totals'],{'EUR':'12.00','USD':'95.00'})
        self.assertEqual((r['source_rows'],r['accepted_rows'],r['rejected_rows'],r['duplicate_rows']),(8,4,3,1))
        self.assertEqual((r['purchase_orders'],r['suppliers']),(3,2))
    def test_leading_zero_sku(self):
        self.assertEqual(inspect_bytes(data())['records'][0]['sku'],'00123')
    def test_unknown_is_not_zero(self):
        r=inspect_bytes(data(received_quantity=''))
        self.assertIsNone(r['records'][0]['received_quantity'])
        self.assertEqual(r['records'][0]['receipt_state'],'Unknown')
        self.assertEqual(r['unknown_received_rows'],1)
    def test_partial(self):
        self.assertEqual(inspect_bytes(data())['records'][0]['receipt_state'],'Partial')
    def test_over_receipt_retained(self):
        self.assertEqual(inspect_bytes(data(received_quantity='12'))['records'][0]['receipt_state'],'Over received')
    def test_zero_retained(self):
        self.assertEqual(inspect_bytes(data(received_quantity='0'))['records'][0]['receipt_state'],'Not received')
    def test_non_numeric_rejects(self):
        for field in ('ordered_quantity','received_quantity','unit_cost'):
            for value in ('NaN','Infinity','1e2','-1','?'):
                with self.subTest(field=field,value=value):
                    r=inspect_bytes(data(**{field:value}))
                    self.assertEqual(r['accepted_rows'],0)
                    self.assertEqual(r['rejected_rows'],1)
    def test_exact_duplicate(self):
        raw=data(); row=raw.splitlines(keepends=True)[1]
        r=inspect_bytes(raw+row)
        self.assertEqual(r['currency_totals'],{'USD':'25.00'})
        self.assertEqual(r['duplicate_rows'],1)
    def test_conflicting_po(self):
        raw=data()+data(supplier='Other').splitlines(keepends=True)[1]
        r=inspect_bytes(raw)
        self.assertEqual(r['rejected_rows'],1)
        self.assertIn('Conflicting PO',r['rejected'][0]['reason'])
    def test_header_rejected(self):
        with self.assertRaises(ValueError): inspect_bytes(b'po,sku\nA,B\n')
    def test_bad_date_rejected(self):
        self.assertEqual(inspect_bytes(data(date='2026-02-30'))['rejected_rows'],1)
    def test_currency_rejected(self):
        self.assertEqual(inspect_bytes(data(currency='US$'))['rejected_rows'],1)
    def test_column_count_report_render(self):
        r=inspect_bytes((','.join(FIELDS)+'\nA,B,C,D,E,F,G,H,I\n').encode())
        self.assertEqual(r['rejected_rows'],1)
        self.assertIn('Column count mismatch',render(r))
    def test_source_hash(self):
        raw=data()
        self.assertEqual(inspect_bytes(raw)['source_sha256'],hashlib.sha256(raw).hexdigest())
    def test_xss_and_json(self):
        payload='</script><script>window.pwned=1</script><svg onload=alert(1)>'
        r=inspect_bytes(data(sku=payload),payload+'.csv')
        doc=render(r)
        self.assertNotIn(payload,doc)
        self.assertEqual(doc.count('<script'),2)
        self.assertIn('&lt;svg',doc)
        embedded=re.search(r'<script id="archive-data" type="application/json">(.*?)</script>',doc,re.S).group(1)
        self.assertEqual(json.loads(embedded)['records'][0]['sku'],payload)
    def test_safe_json_separators(self):
        original={'text':'<>&\u2028\u2029'}
        encoded=safe_json(original)
        self.assertEqual(json.loads(encoded),original)
        self.assertNotIn('<',encoded)
        self.assertNotIn('\u2028',encoded)
    def test_formula_text_is_data(self):
        payload='=HYPERLINK("https://example.invalid","click")'
        r=inspect_bytes(data(sku=payload))
        self.assertEqual(r['records'][0]['sku'],payload)
        self.assertIn('=HYPERLINK(&quot;',render(r))
        self.assertNotIn('href="https://example.invalid',render(r))
    def test_deterministic(self):
        self.assertEqual(render(inspect_bytes(data())),render(inspect_bytes(data())))
    def test_large_decimal_exact(self):
        r=inspect_bytes(data(ordered_quantity='123456789012345678901234567890',unit_cost='2',received_quantity=''))
        self.assertEqual(r['currency_totals']['USD'],'246913578024691357802469135780')
    def test_no_hidden_network(self):
        doc=render(inspect_bytes(data()))
        self.assertNotIn('fetch(',doc)
        self.assertNotIn('XMLHttpRequest',doc)
        self.assertIn("connect-src 'none'",doc)
    def test_template_marker_is_plain_source(self):
        r=inspect_bytes(data(sku='@@DATA@@'))
        self.assertIn('<td>@@DATA@@</td>',render(r))
    def test_multiline_source_reference(self):
        r=inspect_bytes(data(supplier='Two\nLines'))
        self.assertIn('record 1 (ends at line 3)',r['records'][0]['source'])
if __name__=='__main__': unittest.main()
