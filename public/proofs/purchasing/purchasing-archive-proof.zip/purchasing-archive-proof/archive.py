#!/usr/bin/env python3
"""Build a local purchasing archive from the documented Toledo proof schema."""
import argparse, csv, hashlib, html, io, json, re
from collections import defaultdict
from datetime import date
from decimal import Decimal, Context
from pathlib import Path

FIELDS = ('po_id','date','supplier','sku','currency','ordered_quantity','received_quantity','unit_cost')
MAX_BYTES, MAX_ROWS = 10*1024*1024, 50000
ARITHMETIC = Context(prec=100)

def number(value, name, optional=False):
    if optional and not value:
        return None
    if len(value)>40 or not re.fullmatch(r'\d+(?:\.\d{1,6})?',value):
        raise ValueError(name+': expected a non-negative decimal, up to 6 decimal places')
    return Decimal(value)

def inspect_bytes(raw, source='input.csv'):
    if len(raw)>MAX_BYTES:
        raise ValueError('Input exceeds 10 MiB proof limit')
    try:
        reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig'),newline=''),strict=True)
    except UnicodeDecodeError as exc:
        raise ValueError('Input must be UTF-8 CSV') from exc
    if reader.fieldnames!=list(FIELDS):
        raise ValueError('Header must exactly match documented schema: '+','.join(FIELDS))
    records,rejected,duplicates,seen,headers=[],[],[],set(),{}
    totals=defaultdict(Decimal)
    count=0
    for row in reader:
        count+=1
        if count>MAX_ROWS: raise ValueError('Input exceeds 50,000 record proof limit')
        ref=source+': record '+str(count)+' (ends at line '+str(reader.line_num)+')'
        if None in row or any(row[f] is None for f in FIELDS):
            rejected.append({'source':ref,'reason':'Column count mismatch','values':{str(k):v for k,v in row.items()}})
            continue
        original=tuple(row[f] for f in FIELDS)
        if original in seen:
            duplicates.append({'source':ref,'reason':'Exact duplicate row; excluded from totals'})
            continue
        v={f:row[f].strip() for f in FIELDS}
        try:
            for f in ('po_id','supplier','sku'):
                if not v[f] or len(v[f])>500: raise ValueError(f+': required; max 500 characters')
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',v['date']): raise ValueError('Date must be YYYY-MM-DD')
            date.fromisoformat(v['date'])
            if not re.fullmatch(r'[A-Z]{3}',v['currency']): raise ValueError('Currency must be 3 uppercase letters')
            ordered=number(v['ordered_quantity'],'ordered_quantity')
            received=number(v['received_quantity'],'received_quantity',True)
            cost=number(v['unit_cost'],'unit_cost')
            header=(v['date'],v['supplier'],v['currency'])
            if v['po_id'] in headers and headers[v['po_id']]!=header:
                raise ValueError('Conflicting PO date, supplier or currency')
        except ValueError as exc:
            rejected.append({'source':ref,'reason':str(exc),'values':v})
            continue
        seen.add(original)
        headers[v['po_id']]=header
        value=ARITHMETIC.multiply(ordered,cost)
        r=dict(v,source=ref,ordered_quantity=format(ordered,'f'),
               received_quantity=None if received is None else format(received,'f'),
               unit_cost=format(cost,'f'),ordered_line_value=format(value,'f'))
        r['receipt_state']=('Unknown' if received is None else 'Not received' if received==0 else
                            'Partial' if received<ordered else 'Over received' if received>ordered else 'Received')
        records.append(r)
        totals[v['currency']]=ARITHMETIC.add(totals[v['currency']],value)
    supplier_totals=defaultdict(Decimal)
    for r in records: supplier_totals[(r['supplier'],r['currency'])]=ARITHMETIC.add(supplier_totals[(r['supplier'],r['currency'])],Decimal(r['ordered_line_value']))
    return dict(schema='toledo-purchasing-proof-v1',synthetic_fixture=False,source_name=source,
                source_sha256=hashlib.sha256(raw).hexdigest(),source_bytes=len(raw),source_rows=count,
                accepted_rows=len(records),rejected_rows=len(rejected),duplicate_rows=len(duplicates),
                purchase_orders=len(headers),suppliers=len({r['supplier'] for r in records}),
                unknown_received_rows=sum(r['received_quantity'] is None for r in records),
                currency_totals={k:format(v,'f') for k,v in sorted(totals.items())},
                supplier_totals=[dict(supplier=s,currency=c,ordered_line_value=format(v,'f'))
                                 for (s,c),v in sorted(supplier_totals.items())],
                records=records,rejected=rejected,duplicates=duplicates)

def safe_json(data):
    return (json.dumps(data,ensure_ascii=False,sort_keys=True).replace('&',r'\u0026')
            .replace('<',r'\u003c').replace('>',r'\u003e').replace('\u2028',r'\u2028').replace('\u2029',r'\u2029'))

def render(report):
    esc=lambda x:html.escape(str(x),quote=True)
    rows=[]
    for r in report['records']:
        vals=[r['po_id'],r['date'],r['supplier'],r['sku'],r['currency'],r['ordered_quantity'],
              'Unknown' if r['received_quantity'] is None else r['received_quantity'],
              r['receipt_state'],r['unit_cost'],r['ordered_line_value'],r['source']]
        rows.append('<tr class="record" data-currency="'+esc(r['currency'])+'">'+
                    ''.join('<td>'+esc(v)+'</td>' for v in vals)+'</tr>')
    totals=''.join('<div class="money"><span>'+esc(c)+'</span><strong>'+esc(v)+'</strong></div>'
                   for c,v in report['currency_totals'].items())
    suppliers=''.join('<tr><td>'+esc(r['supplier'])+'</td><td>'+esc(r['currency'])+'</td><td>'+
                      esc(r['ordered_line_value'])+'</td></tr>' for r in report['supplier_totals'])
    exceptions=''.join('<tr><td>'+esc(r['source'])+'</td><td>'+esc(r['reason'])+'</td></tr>'
                       for r in report['rejected']+report['duplicates'])
    options=''.join('<option value="'+esc(c)+'">'+esc(c)+'</option>' for c in report['currency_totals'])
    template='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>Toledo · Purchasing archive proof</title><style>
:root{color-scheme:light;--ink:#202821;--paper:#f1f0e9;--line:#8f988d;--muted:#4e5a50;--accent:#d5ea79}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.5 system-ui,sans-serif}header,main,footer{max-width:1440px;margin:auto;padding:28px 36px}header{border-bottom:2px solid var(--ink);display:flex;justify-content:space-between;gap:20px;font:700 13px/1.5 ui-monospace,monospace;letter-spacing:.08em}.eyebrow{font:700 12px/1.5 ui-monospace,monospace;letter-spacing:.08em}h1{font:700 clamp(35px,5vw,66px)/1.04 Georgia,serif;letter-spacing:-.035em;margin:14px 0 22px}h2{font:700 26px/1.2 Georgia,serif;margin:0 0 14px}p{max-width:900px;margin:12px 0}.lead{font-size:19px}.notice{border-left:5px solid var(--ink);padding:12px 16px;background:#e5e7da}.stats{display:flex;flex-wrap:wrap;border-block:1px solid var(--ink);margin:28px 0}.stat{padding:16px 25px 16px 0;min-width:150px}.stat strong{display:block;font:700 30px/1.2 ui-monospace,monospace}.stat span{font-size:13px}.section{padding:26px 0;border-bottom:1px solid var(--line)}.totalbar{display:flex;flex-wrap:wrap;gap:40px}.money span{font:700 13px/1.5 ui-monospace,monospace;display:block}.money strong{font:700 32px/1.4 ui-monospace,monospace}.muted{color:var(--muted);font-size:14px}.filters{display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:22px 0 10px}label{font-weight:650;display:block;font-size:14px}input,select,button{font:inherit;border:1px solid var(--ink);background:#fffef9;color:var(--ink);padding:12px;min-height:48px;border-radius:0}input{min-width:260px;width:100%}.search{flex:1;max-width:600px}button{cursor:pointer;background:var(--accent);font-weight:700}button:hover{background:#c6dd62}:focus-visible{outline:3px solid #365d1d;outline-offset:3px}.scroll{overflow:auto;border:1px solid var(--line);margin:14px 0}caption{text-align:left;padding:11px 13px;font:700 12px/1.5 ui-monospace,monospace}table{border-collapse:collapse;min-width:800px;width:100%;background:#fdfcf7;font-size:14px}th{text-align:left;background:#dfe3d5;font:700 12px/1.5 ui-monospace,monospace;white-space:nowrap}th,td{padding:11px 13px;border-bottom:1px solid #c5c9bd;vertical-align:top}td{font-variant-numeric:tabular-nums}td:last-child{overflow-wrap:anywhere}tbody tr:hover{background:#f0f4df}.twocol{display:grid;grid-template-columns:1fr 1fr;gap:28px}.twocol>section{min-width:0}.twocol table{min-width:450px}.hash{font:12px/1.7 ui-monospace,monospace;overflow-wrap:anywhere}.empty{padding:20px;background:#e5e7da}footer{font:12px/1.7 ui-monospace,monospace;color:var(--muted)}[hidden]{display:none!important}@media(max-width:750px){header,main,footer{padding:22px 18px}.twocol{grid-template-columns:1fr}header{flex-direction:column;gap:6px}.stat{min-width:33%}input{min-width:180px}.filters>*{flex:1}}@media print{.filters{display:none}.scroll{overflow:visible}table{font-size:9px;min-width:0}th,td{padding:3px}.twocol{display:block}header,main,footer{padding:10px}body{background:white}}
</style></head><body><header><span>TOLEDO TECHNOLOGIES / EXIT PACK</span><span>LOCAL PROOF · NO NETWORK</span></header><main>
<div class="eyebrow">@@LABEL@@</div><h1>Keep the purchasing history.<br>Own the record.</h1><p class="lead">A searchable purchasing book built from a supplied CSV. Every accepted line points back to its source. Nothing is written to a store.</p>
<p class="notice"><strong>@@PROOF@@</strong> This uses Toledo’s documented demonstration schema. Real Stocky export compatibility has not been tested. It does not recover absent data or restore historical purchase orders in Shopify.</p>
<div class="stats"><div class="stat"><strong>@@SOURCE_ROWS@@</strong><span>input records</span></div><div class="stat"><strong>@@ACCEPTED@@</strong><span>accepted lines</span></div><div class="stat"><strong>@@POS@@</strong><span>purchase orders</span></div><div class="stat"><strong>@@REJECTED@@</strong><span>rejected lines</span></div><div class="stat"><strong>@@DUPLICATES@@</strong><span>exact duplicates excluded</span></div></div>
<section class="section"><h2>Ordered line value</h2><div class="totalbar">@@TOTALS@@</div><p class="muted">Sum of ordered quantity × unit cost for accepted lines, separately by currency. These are not actual spend, payments, received value, tax, freight or inventory valuation. Totals cover all accepted lines and do not change with search.</p></section>
<section class="section"><h2>Find the original purchase</h2><div class="filters"><div class="search"><label for="query">Search PO, SKU or supplier</label><input id="query" type="search" placeholder="Try 00123, PO-100, or North Bolt" autocomplete="off"></div><div><label for="currency">Currency</label><select id="currency"><option value="">All currencies</option>@@OPTIONS@@</select></div><button id="reset" type="button">Clear filters</button></div><p id="status" class="muted" role="status" aria-live="polite">@@ACCEPTED@@ of @@ACCEPTED@@ accepted lines shown.</p>
<div class="scroll" role="region" aria-label="Purchasing lines, horizontally scrollable" tabindex="0"><table><caption>Accepted purchasing lines with original record references</caption><thead><tr><th scope="col">PO</th><th scope="col">Date</th><th scope="col">Supplier</th><th scope="col">SKU</th><th scope="col">Currency</th><th scope="col">Ordered</th><th scope="col">Received</th><th scope="col">Receipt state</th><th scope="col">Unit cost</th><th scope="col">Ordered value</th><th scope="col">Source record</th></tr></thead><tbody>@@ROWS@@</tbody></table></div><p id="empty" class="empty" hidden>No accepted lines match. Clear the search or select another currency.</p><p class="muted">@@UNKNOWN@@ accepted @@LINE_NOUN@@ @@HAVE_VERB@@ no received quantity recorded. Unknown stays unknown; it is never converted to zero.</p></section>
<div class="twocol"><section class="section"><h2>Supplier totals</h2><p class="muted">Ordered line value, grouped by supplier and currency.</p><div class="scroll" role="region" aria-label="Supplier totals" tabindex="0"><table><caption>Ordered line value by supplier and currency</caption><thead><tr><th scope="col">Supplier</th><th scope="col">Currency</th><th scope="col">Ordered value</th></tr></thead><tbody>@@SUPPLIERS@@</tbody></table></div></section><section class="section"><h2>Source and coverage</h2><p><strong>@@SOURCE@@</strong></p><p class="hash">SHA-256<br>@@HASH@@</p><p class="muted">Accepted + rejected + duplicate records = @@SOURCE_ROWS@@ input records. This reconciles the supplied file only; it cannot establish whether it contains every historical purchase.</p><p class="muted">No live API, inferred missing fields, currency conversion or accounting claims. The accompanying report.json contains machine-readable records and rejection details.</p></section></div>
<section class="section"><h2>Rejected and duplicate records</h2><p class="muted">Excluded records remain accounted for. Exact duplicate exclusion is a proof policy; legitimate identical source lines require review against a real export’s identifiers.</p><div class="scroll" role="region" aria-label="Rejected and duplicate records" tabindex="0"><table><caption>Records excluded from calculated totals</caption><thead><tr><th scope="col">Source</th><th scope="col">Reason</th></tr></thead><tbody>@@EXCEPTIONS@@</tbody></table></div></section>
</main><footer>Generated locally with Python standard library. No external scripts, fonts, uploads or network requests.<br>Source values are treated as text. The archive remains usable independently of Toledo.</footer>
<script id="archive-data" type="application/json">@@DATA@@</script><script>
'use strict';
const query=document.getElementById('query'),currency=document.getElementById('currency'),lines=[...document.querySelectorAll('tr.record')];
function filter(){const q=query.value.trim().toLocaleLowerCase(),c=currency.value;let count=0;for(const row of lines){const cells=row.cells,text=[cells[0].textContent,cells[2].textContent,cells[3].textContent].join(' ').toLocaleLowerCase(),show=(!q||text.includes(q))&&(!c||row.dataset.currency===c);row.hidden=!show;if(show)count++;}document.getElementById('status').textContent=count+' of '+lines.length+' accepted lines shown.';document.getElementById('empty').hidden=count!==0;}
query.addEventListener('input',filter);currency.addEventListener('change',filter);document.getElementById('reset').addEventListener('click',()=>{query.value='';currency.value='';filter();query.focus();});
</script></body></html>'''
    d=dict(LABEL='SYNTHETIC DEMONSTRATION' if report['synthetic_fixture'] else 'DOCUMENTED SCHEMA PROOF',
           PROOF='All purchases below are invented test data.' if report['synthetic_fixture'] else 'Private proof; verify source coverage.',
           SOURCE_ROWS=report['source_rows'],ACCEPTED=report['accepted_rows'],POS=report['purchase_orders'],
           REJECTED=report['rejected_rows'],DUPLICATES=report['duplicate_rows'],UNKNOWN=report['unknown_received_rows'],
           LINE_NOUN='line' if report['unknown_received_rows']==1 else 'lines',HAVE_VERB='has' if report['unknown_received_rows']==1 else 'have',SOURCE=esc(report['source_name']),HASH=report['source_sha256'],TOTALS=totals,OPTIONS=options,
           ROWS=''.join(rows),SUPPLIERS=suppliers,EXCEPTIONS=exceptions or '<tr><td colspan="2">None.</td></tr>',
           DATA=safe_json(report))
    return re.sub(r'@@([A-Z_]+)@@',lambda m:str(d[m.group(1)]),template)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--synthetic',action='store_true')
    args=parser.parse_args()
    try:
        if args.input.stat().st_size>MAX_BYTES: raise ValueError('Input exceeds 10 MiB proof limit')
        report=inspect_bytes(args.input.read_bytes(),args.input.name)
    except (OSError,ValueError,csv.Error) as exc:
        parser.exit(2,'Input rejected: '+str(exc)+'\n')
    report['synthetic_fixture']=args.synthetic
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'index.html').write_text(render(report),encoding='utf-8')
    (args.output/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'html':str(args.output/'index.html'),'accepted':report['accepted_rows'],
                      'rejected':report['rejected_rows'],'duplicates':report['duplicate_rows'],
                      'currency_totals':report['currency_totals']}))
if __name__=='__main__': main()
