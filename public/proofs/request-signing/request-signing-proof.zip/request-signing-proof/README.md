# WooCommerce / BIGO integration — offline technical proof

Prepared 10 September 2026 as an inspectable request-signing and order-safety demonstration. **This is a newly written demonstration, not a past client project, deployed integration or proof that the merchant's existing problem has been diagnosed.** No BIGO endpoints were contacted, no WooCommerce code ran, and no real credentials, private keys or customer data were used.

## Run and environment

Inspected local runtime: Python 3.12.3, cryptography installed, OpenSSL installed; PHP is not installed. No package installation or spending was needed. From this directory:

    python3 proof.py
    python3 -m unittest -v

The demo prints only pass/fail, byte lengths/hashes and synthetic state transitions. It generates a new 2048-bit RSA key in memory and does not serialize, print or save the private key. The OpenSSL test temporarily writes only the public key, synthetic signed bytes and signature, then removes those files. The private key never leaves process memory.

Files:
- proof.py — executable byte-contract proof and SQLite state simulation.
- test_proof.py — 39 tests, including independent OpenSSL verification and concurrent-worker claim protection.
- technical-note.md — concise explanation of the proof and its limits.
- verification.json — captured test results and runtime/source hashes.
- demo-result.json — a saved synthetic run with no key or raw payload logging.

## Signature contract under test

The linked public example signs:

    exact_request_body_bytes + exact_URI_bytes + decimal_timestamp_seconds_bytes

The signature is RSA PKCS#1 v1.5 with SHA-256, Base64-encoded. This is a detached HTTP-header signature, not necessarily a JWT. The proof serializes JSON once, signs those bytes and keeps those same bytes in an immutable prepared request. It demonstrates that changing insignificant-looking JSON whitespace, key order, Unicode escaping, a trailing newline, the URI or timestamp invalidates the signature.

The compact UTF-8 JSON style is this proof's chosen serialization. The source example does not establish a canonical JSON requirement: whatever serialization is used must match the transmitted bytes. URI query inclusion and encoding, client/key version, accepted timestamp skew, actual reseller endpoint and error schema must be confirmed against the merchant's BIGO-supplied documents.

A valid cryptographic signature does not establish timestamp freshness, authorization, IP allowlisting, key registration or request correctness. The optional 60-second freshness function is explicitly an illustrative local policy, not a claim about BIGO's allowed window. HTTP 200 is deliberately not accepted as an order-fulfillment classification.

## Order-safety simulation

A trusted caller marks a synthetic paid order; a real implementation must verify payment from the authoritative WooCommerce order/payment record rather than a success URL or unverified webhook. The example recipient/product/unit/amount fields are invented and are **not a BIGO recharge payload**.

The SQLite ledger records event IDs and an order-snapshot fingerprint, uses transactions to claim work, and commits in-flight state before the simulated external side effect. Duplicate events and different events for an already queued/fulfilled order do not create a new attempt. Conflicting order data is rejected.

Transitions:
- ready -> in_flight on one successful atomic claim.
- confirmed success with a simulated provider reference -> fulfilled.
- definitively rejected -> failed.
- definitely not sent -> a bounded retry with backoff (maximum three attempts).
- timeout, lost response or other unknown outcome -> uncertain.
- uncertain -> fulfilled only after simulated authoritative confirmation, or ready only after simulated confirmation of non-execution.
- restart after workers have stopped -> previous in_flight entries become uncertain, never automatically resent.

**This does not establish BIGO idempotency or exactly-once external delivery.** A timeout might mean the recharge succeeded but its response was lost. Local duplicate suppression cannot solve that. The real adapter needs documented provider idempotency semantics and/or authenticated transaction lookup, using a stable merchant transaction identifier. If neither exists, an ambiguous recharge stays blocked for reconciliation instead of risking a second recharge.

Outcome classification and reconciliation evidence are injected into this simulation. There is no real provider response parser, transport, status lookup, job queue, refund workflow, WooCommerce hook, scheduler or admin interface here. Recovery must only run after old workers have stopped. This is a demonstration of safety invariants, not an operational system.

## Merchant evidence needed to turn it into a repair

1. Current BIGO reseller/recharge documentation, exact signature input rules, official test endpoint, error-code meanings, supported merchant order ID, duplicate-request behavior and transaction-status lookup.
2. Existing custom plugin/integration code and redacted failure examples; versions of WordPress, WooCommerce, PHP and relevant gateway/plugins.
3. Authorized staging access and hosting/network configuration. Verify the outbound IP from the actual PHP/worker execution environment, including NAT/proxy behavior, and confirm static-egress/allowlisting with the host and BIGO.
4. Confirmation of which public key/key version BIGO registered. Private keys should be handled through a restricted server-side secret path, not email, browser tools or logs.
5. An approved non-monetary test path, followed by an explicitly approved small end-to-end test if the provider requires actual value. This proof has performed neither.
6. A definition of fulfillment success, safe retry outcomes and support/reconciliation responsibilities. Inspect business response fields; do not equate gateway success with a successful recharge.

A production patch would use the existing supported PHP/WordPress conventions, a durable job/attempt record with atomic uniqueness, payment verification and state checks, carefully classified responses, restricted key storage, and redacted diagnostics. Wire-level cURL/body captures requested by BIGO should be made only in the approved test environment and shared securely with authorized support; never print real secrets or customer payloads into ordinary logs.

## Sources and limits

- Public signature example: https://raw.githubusercontent.com/yothen/Bigo-Open-Api/main/demo/rs256_sign_req.py
- Public server access guide: https://raw.githubusercontent.com/yothen/Bigo-Open-Api/main/BIGOLIVEOpenPlatformAccessGuide_forserver.md

The GitHub repository's current official status and applicability to this merchant's reseller integration have not been established. It is a public reference for a candidate byte contract. Its sample logs request material; that behavior was deliberately not reproduced. The production source of truth must be the documentation BIGO supplied to the merchant.
