#!/usr/bin/env python3
"""Offline RSA byte-contract proof and simulated paid-order safety ledger. No network."""
import base64
import hashlib
import json
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def encode_body(payload):
    """Serialize once. This is this proof's policy, not a BIGO canonical-JSON rule."""
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def signing_bytes(body, uri, timestamp):
    if not isinstance(body, bytes):
        raise TypeError("body must be the already-serialized bytes that would be sent")
    if not isinstance(uri, str) or not uri.startswith("/") or uri.startswith("//"):
        raise ValueError("URI must be an origin-relative path")
    if not uri.isascii() or "#" in uri or any(ch.isspace() or ord(ch) < 32 for ch in uri):
        raise ValueError("URI must be exact ASCII request-target bytes without fragments/whitespace")
    if not isinstance(timestamp, str) or not re.fullmatch(r"(?:0|[1-9][0-9]*)", timestamp):
        raise ValueError("Timestamp must be a decimal seconds string")
    return body + uri.encode("ascii") + timestamp.encode("ascii")


@dataclass(frozen=True)
class PreparedRequest:
    """Immutable local representation. There is intentionally no HTTP sender."""
    body: bytes
    uri: str
    timestamp: str
    signature_b64: str
    method: str = "POST"

    def headers(self, client_id="SYNTHETIC-CLIENT", key_version="0"):
        if any("\r" in value or "\n" in value for value in (client_id, key_version)):
            raise ValueError("Header values must not contain newlines")
        return {"Content-Type": "application/json", "bigo-client-id": client_id,
                "bigo-timestamp": self.timestamp, "bigo-client-version": key_version,
                "bigo-oauth-signature": self.signature_b64}


def prepare(private_key, payload, uri, timestamp):
    body = encode_body(payload)
    message = signing_bytes(body, uri, timestamp)
    signature = private_key.sign(message, padding.PKCS1v15(), hashes.SHA256())
    return PreparedRequest(body, uri, timestamp, base64.b64encode(signature).decode("ascii"))


def verify(public_key, body, uri, timestamp, signature_b64):
    try:
        signature = base64.b64decode(signature_b64, validate=True)
        public_key.verify(signature, signing_bytes(body, uri, timestamp), padding.PKCS1v15(), hashes.SHA256())
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def fresh_for_example_policy(timestamp, now, tolerance=60):
    """Illustrative local policy only; BIGO's real acceptance window is unverified."""
    if not re.fullmatch(r"(?:0|[1-9][0-9]*)", timestamp):
        return False
    return abs(int(timestamp) - now) <= tolerance


class Outcome(str, Enum):
    CONFIRMED_SUCCESS = "confirmed_success"
    DEFINITIVELY_REJECTED = "definitively_rejected"
    DEFINITELY_NOT_SENT = "definitely_not_sent"
    UNKNOWN = "unknown"


class Resolution(str, Enum):
    CONFIRMED_SUCCESS = "confirmed_success"
    CONFIRMED_NOT_EXECUTED = "confirmed_not_executed"


def snapshot_fingerprint(snapshot):
    """Example fields only; this is NOT a documented BIGO recharge payload."""
    needed = {"recipient", "product", "recharge_units", "amount_minor", "currency"}
    if set(snapshot) != needed:
        raise ValueError("Synthetic order snapshot must have exactly the documented fields")
    if not all(isinstance(snapshot[k], str) and snapshot[k] for k in ("recipient", "product")):
        raise ValueError("Recipient and product must be nonempty synthetic strings")
    if not all(type(snapshot[k]) is int and snapshot[k] > 0 for k in ("recharge_units", "amount_minor")):
        raise ValueError("Amounts and units must be positive integer values")
    if not isinstance(snapshot["currency"], str) or not re.fullmatch(r"[A-Z]{3}", snapshot["currency"]):
        raise ValueError("Currency must be three uppercase letters")
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


class Ledger:
    """SQLite simulation, not a WooCommerce plugin or BIGO idempotency implementation."""
    MAX_ATTEMPTS = 3

    def __init__(self, path=":memory:"):
        self.db = sqlite3.connect(path, timeout=5, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS orders (
          order_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL,
          state TEXT NOT NULL CHECK(state IN ('ready','in_flight','retry_pending','uncertain','fulfilled','failed')),
          attempts INTEGER NOT NULL DEFAULT 0, retry_at INTEGER NOT NULL DEFAULT 0,
          provider_ref TEXT, last_outcome TEXT);
        CREATE TABLE IF NOT EXISTS events (
          event_id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(order_id),
          fingerprint TEXT NOT NULL);
        """)

    def close(self):
        self.db.close()

    @contextmanager
    def transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def get(self, order_id):
        row = self.db.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
        return dict(row) if row else None

    def paid_event(self, event_id, order_id, snapshot, *, payment_verified):
        """Caller must establish payment from a trusted order record, not a browser redirect."""
        if payment_verified is not True:
            raise ValueError("Payment has not been authoritatively verified")
        if not all(isinstance(v, str) and v and len(v) <= 100 for v in (event_id, order_id)):
            raise ValueError("Event and order identifiers required, max 100 characters")
        fingerprint = snapshot_fingerprint(snapshot)
        with self.transaction():
            event = self.db.execute("SELECT * FROM events WHERE event_id=?", (event_id,)).fetchone()
            if event:
                if event["order_id"] != order_id or event["fingerprint"] != fingerprint:
                    raise ValueError("Event identifier collision or changed order snapshot")
                return "duplicate_event"
            order = self.get(order_id)
            if order and order["fingerprint"] != fingerprint:
                raise ValueError("Order snapshot changed; explicit reconciliation required")
            if not order:
                self.db.execute("INSERT INTO orders(order_id,fingerprint,state) VALUES (?,?,'ready')",
                                (order_id, fingerprint))
            self.db.execute("INSERT INTO events VALUES (?,?,?)", (event_id, order_id, fingerprint))
            return "existing_order" if order else "queued"

    def claim(self, order_id, now):
        """Commit the in-flight state BEFORE the simulated side effect."""
        with self.transaction():
            order = self.get(order_id)
            if not order or order["state"] not in ("ready", "retry_pending") or now < order["retry_at"]:
                return None
            if order["attempts"] >= self.MAX_ATTEMPTS:
                self.db.execute("UPDATE orders SET state='failed',last_outcome='retry_limit' WHERE order_id=?", (order_id,))
                return None
            attempt = order["attempts"] + 1
            self.db.execute("UPDATE orders SET state='in_flight',attempts=? WHERE order_id=?", (attempt, order_id))
            return attempt

    def finish(self, order_id, attempt, outcome, now, provider_ref=None):
        if not isinstance(outcome, Outcome):
            raise ValueError("A classified simulation outcome is required, not an HTTP code")
        if outcome is Outcome.CONFIRMED_SUCCESS and not provider_ref:
            raise ValueError("Success requires a verified provider transaction reference")
        with self.transaction():
            order = self.get(order_id)
            if not order or order["state"] != "in_flight" or order["attempts"] != attempt:
                raise ValueError("Stale attempt or state; must reconcile")
            retry_at = 0
            if outcome is Outcome.CONFIRMED_SUCCESS:
                state = "fulfilled"
            elif outcome is Outcome.DEFINITIVELY_REJECTED:
                state = "failed"
            elif outcome is Outcome.DEFINITELY_NOT_SENT:
                state = "retry_pending" if attempt < self.MAX_ATTEMPTS else "failed"
                retry_at = now + 5 * (2 ** (attempt - 1))
            else:
                state = "uncertain"
            self.db.execute("UPDATE orders SET state=?,retry_at=?,provider_ref=?,last_outcome=? WHERE order_id=?",
                            (state, retry_at, provider_ref, outcome.value, order_id))
            return state

    def recover_in_flight_after_worker_stop(self):
        """Only call after old workers have stopped; never treat stale locks as safe to resend."""
        with self.transaction():
            result = self.db.execute("UPDATE orders SET state='uncertain',last_outcome='worker_stopped' WHERE state='in_flight'")
            return result.rowcount

    def reconcile(self, order_id, resolution, *, simulated_evidence, provider_ref=None):
        """Simulation input; a real adapter must verify authenticated authoritative provider evidence."""
        if not isinstance(resolution, Resolution) or not simulated_evidence:
            raise ValueError("Explicit simulated reconciliation evidence required")
        if resolution is Resolution.CONFIRMED_SUCCESS and not provider_ref:
            raise ValueError("Verified provider reference required")
        with self.transaction():
            order = self.get(order_id)
            if not order or order["state"] != "uncertain":
                raise ValueError("Only uncertain orders can be reconciled")
            state = "fulfilled" if resolution is Resolution.CONFIRMED_SUCCESS else "ready"
            if state == "ready" and order["attempts"] >= self.MAX_ATTEMPTS:
                state = "failed"
            self.db.execute("UPDATE orders SET state=?,retry_at=0,provider_ref=?,last_outcome=? WHERE order_id=?",
                            (state, provider_ref, "reconciled_" + resolution.value, order_id))
            return state


SYNTHETIC_ORDER = {"recipient": "DEMO-RECIPIENT", "product": "DEMO-PACK",
                   "recharge_units": 100, "amount_minor": 999, "currency": "AUD"}


def demo():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    request = prepare(private_key, {"msg": "synthetic byte-contract test"}, "/oauth2/test_sign", "1789034400")
    signature_checks = {
        "exact_bytes_verify": verify(private_key.public_key(), request.body, request.uri, request.timestamp, request.signature_b64),
        "body_tamper_rejected": not verify(private_key.public_key(), request.body + b"\n", request.uri, request.timestamp, request.signature_b64),
        "uri_tamper_rejected": not verify(private_key.public_key(), request.body, request.uri + "/", request.timestamp, request.signature_b64),
        "timestamp_tamper_rejected": not verify(private_key.public_key(), request.body, request.uri, "1789034401", request.signature_b64),
    }
    ledger = Ledger()
    queued = ledger.paid_event("demo-event", "demo-order", SYNTHETIC_ORDER, payment_verified=True)
    duplicate = ledger.paid_event("demo-event", "demo-order", SYNTHETIC_ORDER, payment_verified=True)
    attempt = ledger.claim("demo-order", 0)
    uncertain = ledger.finish("demo-order", attempt, Outcome.UNKNOWN, 1)
    blocked = ledger.claim("demo-order", 100) is None
    resolved = ledger.reconcile("demo-order", Resolution.CONFIRMED_SUCCESS,
                                simulated_evidence="SYNTHETIC_STATUS_LOOKUP", provider_ref="DEMO-PROVIDER-TXN")
    ledger.close()
    return {"scope": "OFFLINE SYNTHETIC PROOF; no BIGO request sent; no WooCommerce code executed",
            "signature_checks": signature_checks,
            "byte_evidence": {"body_length": len(request.body), "body_sha256": hashlib.sha256(request.body).hexdigest(),
                              "preimage_sha256": hashlib.sha256(signing_bytes(request.body, request.uri, request.timestamp)).hexdigest()},
            "state_checks": {"initial": queued, "duplicate": duplicate, "after_unknown": uncertain,
                             "retry_blocked_while_uncertain": blocked, "after_simulated_reconciliation": resolved},
            "key_handling": "ephemeral 2048-bit key generated in memory; no key or payload logged"}

if __name__ == "__main__":
    print(json.dumps(demo(), indent=2))
