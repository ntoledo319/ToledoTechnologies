import base64
import contextlib
import dataclasses
import io
import json
import shutil
import subprocess
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from proof import (Ledger, Outcome, Resolution, SYNTHETIC_ORDER, demo, encode_body,
                   fresh_for_example_policy, prepare, signing_bytes, snapshot_fingerprint, verify)


class SignatureTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.req = prepare(cls.key, {"msg": "hello", "recipient": "演示"}, "/oauth2/test_sign", "1789034400")

    def test_exact_preimage_contract(self):
        expected = '{"msg":"hello","recipient":"演示"}/oauth2/test_sign1789034400'.encode()
        self.assertEqual(signing_bytes(self.req.body, self.req.uri, self.req.timestamp), expected)

    def test_exact_signature_verifies(self):
        r = self.req
        self.assertTrue(verify(self.key.public_key(), r.body, r.uri, r.timestamp, r.signature_b64))

    def test_whitespace_serialization_change_rejected(self):
        r = self.req
        body = json.dumps(json.loads(r.body), ensure_ascii=False).encode()
        self.assertEqual(json.loads(body), json.loads(r.body))
        self.assertNotEqual(body, r.body)
        self.assertFalse(verify(self.key.public_key(), body, r.uri, r.timestamp, r.signature_b64))

    def test_key_order_change_rejected(self):
        r = self.req
        self.assertFalse(verify(self.key.public_key(), encode_body({"recipient": "演示", "msg": "hello"}),
                                r.uri, r.timestamp, r.signature_b64))

    def test_ascii_escape_serialization_rejected(self):
        r = self.req
        body = json.dumps(json.loads(r.body), ensure_ascii=True, separators=(",", ":")).encode()
        self.assertFalse(verify(self.key.public_key(), body, r.uri, r.timestamp, r.signature_b64))

    def test_trailing_newline_rejected(self):
        r = self.req
        self.assertFalse(verify(self.key.public_key(), r.body + b"\n", r.uri, r.timestamp, r.signature_b64))

    def test_uri_tampering_rejected(self):
        r = self.req
        for uri in (r.uri + "/", r.uri + "?a=1", "/oauth2/Test_sign"):
            with self.subTest(uri=uri):
                self.assertFalse(verify(self.key.public_key(), r.body, uri, r.timestamp, r.signature_b64))

    def test_timestamp_tampering_rejected(self):
        r = self.req
        self.assertFalse(verify(self.key.public_key(), r.body, r.uri, "1789034401", r.signature_b64))

    def test_wrong_key_rejected(self):
        r = self.req
        other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.assertFalse(verify(other.public_key(), r.body, r.uri, r.timestamp, r.signature_b64))

    def test_signature_tamper_rejected(self):
        r = self.req
        sig = bytearray(base64.b64decode(r.signature_b64)); sig[0] ^= 1
        self.assertFalse(verify(self.key.public_key(), r.body, r.uri, r.timestamp, base64.b64encode(sig)))

    def test_invalid_base64_rejected(self):
        r = self.req
        self.assertFalse(verify(self.key.public_key(), r.body, r.uri, r.timestamp, "***not-base64***"))

    def test_timestamp_format_rejected(self):
        for stamp in ("+123", "0123", "1.23", "-1", "123\n", ""):
            with self.assertRaises(ValueError):
                signing_bytes(b"{}", "/test", stamp)

    def test_uri_format_rejected(self):
        for uri in ("https://example.invalid/test", "//example.invalid", "/a#fragment", "/bad path", "/演示"):
            with self.assertRaises(ValueError):
                signing_bytes(b"{}", uri, "123")

    def test_request_immutable(self):
        with self.assertRaises(dataclasses.FrozenInstanceError):
            self.req.body = b"changed"

    def test_no_nan_serialization(self):
        with self.assertRaises(ValueError):
            encode_body({"amount": float("nan")})

    def test_freshness_is_separate_policy(self):
        r = self.req
        self.assertTrue(verify(self.key.public_key(), r.body, r.uri, r.timestamp, r.signature_b64))
        self.assertFalse(fresh_for_example_policy(r.timestamp, int(r.timestamp) + 61))
        self.assertTrue(fresh_for_example_policy(r.timestamp, int(r.timestamp) + 60))

    @unittest.skipUnless(shutil.which("openssl"), "OpenSSL unavailable for independent verification")
    def test_independent_openssl_verification(self):
        r = self.req
        with tempfile.TemporaryDirectory(prefix="bigo-public-proof-") as directory:
            root = Path(directory)
            (root / "public.pem").write_bytes(self.key.public_key().public_bytes(
                serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
            (root / "message.bin").write_bytes(signing_bytes(r.body, r.uri, r.timestamp))
            (root / "signature.bin").write_bytes(base64.b64decode(r.signature_b64))
            result = subprocess.run(["openssl", "dgst", "-sha256", "-verify", str(root / "public.pem"),
                                     "-signature", str(root / "signature.bin"), str(root / "message.bin")],
                                    capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr.decode())
            self.assertIn(b"Verified OK", result.stdout)
            self.assertFalse(any("private" in p.name for p in root.iterdir()))


class LedgerTest(unittest.TestCase):
    def setUp(self):
        self.ledger = Ledger()

    def tearDown(self):
        self.ledger.close()

    def queue(self):
        return self.ledger.paid_event("evt-1", "order-1", SYNTHETIC_ORDER, payment_verified=True)

    def test_unpaid_cannot_queue(self):
        with self.assertRaises(ValueError):
            self.ledger.paid_event("evt-1", "order-1", SYNTHETIC_ORDER, payment_verified=False)
        self.assertIsNone(self.ledger.get("order-1"))

    def test_duplicate_event(self):
        self.assertEqual(self.queue(), "queued")
        self.assertEqual(self.queue(), "duplicate_event")
        self.assertEqual(self.ledger.get("order-1")["attempts"], 0)

    def test_distinct_events_same_order_no_requeue(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.ledger.finish("order-1", attempt, Outcome.CONFIRMED_SUCCESS, 1, "SIM-TXN-1")
        result = self.ledger.paid_event("evt-2", "order-1", SYNTHETIC_ORDER, payment_verified=True)
        self.assertEqual(result, "existing_order")
        self.assertIsNone(self.ledger.claim("order-1", 999))
        self.assertEqual(self.ledger.get("order-1")["state"], "fulfilled")

    def test_event_id_collision(self):
        self.queue()
        with self.assertRaises(ValueError):
            self.ledger.paid_event("evt-1", "order-2", SYNTHETIC_ORDER, payment_verified=True)
        self.assertIsNone(self.ledger.get("order-2"))

    def test_changed_snapshot_rejected(self):
        self.queue()
        changed = dict(SYNTHETIC_ORDER, recharge_units=200)
        with self.assertRaises(ValueError):
            self.ledger.paid_event("evt-2", "order-1", changed, payment_verified=True)

    def test_fingerprint_key_order_independent(self):
        self.assertEqual(snapshot_fingerprint(SYNTHETIC_ORDER),
                         snapshot_fingerprint(dict(reversed(list(SYNTHETIC_ORDER.items())))))

    def test_double_claim_suppressed(self):
        self.queue()
        self.assertEqual(self.ledger.claim("order-1", 0), 1)
        self.assertIsNone(self.ledger.claim("order-1", 0))

    def test_unknown_outcome_no_blind_retry(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.assertEqual(self.ledger.finish("order-1", attempt, Outcome.UNKNOWN, 1), "uncertain")
        self.assertIsNone(self.ledger.claim("order-1", 999999))
        self.assertEqual(self.ledger.get("order-1")["attempts"], 1)

    def test_http_200_is_not_success_classifier(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        with self.assertRaises(ValueError):
            self.ledger.finish("order-1", attempt, 200, 1)
        self.assertEqual(self.ledger.get("order-1")["state"], "in_flight")

    def test_only_known_not_sent_gets_bounded_backoff(self):
        self.queue()
        attempt = self.ledger.claim("order-1", 0)
        self.assertEqual(self.ledger.finish("order-1", attempt, Outcome.DEFINITELY_NOT_SENT, 1), "retry_pending")
        self.assertIsNone(self.ledger.claim("order-1", 5))
        self.assertEqual(self.ledger.claim("order-1", 6), 2)

    def test_maximum_attempts(self):
        self.queue()
        for expected in range(1, 4):
            attempt = self.ledger.claim("order-1", expected * 100)
            self.assertEqual(attempt, expected)
            state = self.ledger.finish("order-1", attempt, Outcome.DEFINITELY_NOT_SENT, expected * 100)
        self.assertEqual(state, "failed")
        self.assertIsNone(self.ledger.claim("order-1", 100000))

    def test_late_result_wrong_attempt_rejected(self):
        self.queue(); self.ledger.claim("order-1", 0)
        self.ledger.finish("order-1", 1, Outcome.DEFINITELY_NOT_SENT, 1)
        self.ledger.claim("order-1", 6)
        with self.assertRaises(ValueError):
            self.ledger.finish("order-1", 1, Outcome.CONFIRMED_SUCCESS, 7, "SIM-TXN")

    def test_definitive_rejection_terminal(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.assertEqual(self.ledger.finish("order-1", attempt, Outcome.DEFINITIVELY_REJECTED, 1), "failed")
        self.assertIsNone(self.ledger.claim("order-1", 999))

    def test_unknown_reconciled_success_not_resent(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.ledger.finish("order-1", attempt, Outcome.UNKNOWN, 1)
        self.assertEqual(self.ledger.reconcile("order-1", Resolution.CONFIRMED_SUCCESS,
                         simulated_evidence="SIM-STATUS", provider_ref="SIM-TXN"), "fulfilled")
        self.assertIsNone(self.ledger.claim("order-1", 999))

    def test_unknown_confirmed_not_executed_allows_next_attempt(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.ledger.finish("order-1", attempt, Outcome.UNKNOWN, 1)
        self.ledger.reconcile("order-1", Resolution.CONFIRMED_NOT_EXECUTED, simulated_evidence="SIM-STATUS")
        self.assertEqual(self.ledger.claim("order-1", 2), 2)

    def test_success_requires_reference(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        with self.assertRaises(ValueError):
            self.ledger.finish("order-1", attempt, Outcome.CONFIRMED_SUCCESS, 1)
        self.assertEqual(self.ledger.get("order-1")["state"], "in_flight")

    def test_reconciliation_requires_evidence(self):
        self.queue(); attempt = self.ledger.claim("order-1", 0)
        self.ledger.finish("order-1", attempt, Outcome.UNKNOWN, 1)
        with self.assertRaises(ValueError):
            self.ledger.reconcile("order-1", Resolution.CONFIRMED_NOT_EXECUTED, simulated_evidence="")
        self.assertEqual(self.ledger.get("order-1")["state"], "uncertain")

    def test_restart_persists_uncertainty_and_event_dedup(self):
        with tempfile.TemporaryDirectory(prefix="bigo-ledger-proof-") as directory:
            path = str(Path(directory) / "state.sqlite")
            first = Ledger(path)
            first.paid_event("evt", "order", SYNTHETIC_ORDER, payment_verified=True)
            first.claim("order", 0); first.close()
            second = Ledger(path)
            self.assertEqual(second.recover_in_flight_after_worker_stop(), 1)
            self.assertIsNone(second.claim("order", 999))
            self.assertEqual(second.paid_event("evt", "order", SYNTHETIC_ORDER, payment_verified=True), "duplicate_event")
            second.close()

    def test_concurrent_workers_only_one_claim(self):
        with tempfile.TemporaryDirectory(prefix="bigo-concurrency-proof-") as directory:
            path = str(Path(directory) / "state.sqlite")
            setup = Ledger(path)
            setup.paid_event("evt", "order", SYNTHETIC_ORDER, payment_verified=True); setup.close()
            barrier = threading.Barrier(2)
            def worker():
                ledger = Ledger(path)
                try:
                    barrier.wait(timeout=5)
                    return ledger.claim("order", 0)
                finally:
                    ledger.close()
            with ThreadPoolExecutor(max_workers=2) as pool:
                results = list(pool.map(lambda _: worker(), range(2)))
            self.assertEqual(results.count(1), 1)
            self.assertEqual(results.count(None), 1)

    def test_sql_identifier_not_executed(self):
        order = "order'); DROP TABLE orders;--"
        self.ledger.paid_event("evt", order, SYNTHETIC_ORDER, payment_verified=True)
        self.assertEqual(self.ledger.claim(order, 0), 1)

    def test_boolean_not_valid_amount(self):
        with self.assertRaises(ValueError):
            snapshot_fingerprint(dict(SYNTHETIC_ORDER, amount_minor=True))


class DemoTest(unittest.TestCase):
    def test_no_key_payload_or_signature_logging(self):
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            output = demo()
        self.assertEqual(stream.getvalue(), "")
        serialized = json.dumps(output)
        self.assertNotIn("PRIVATE KEY", serialized)
        self.assertNotIn("DEMO-RECIPIENT", serialized)
        self.assertNotIn("signature_b64", serialized)
        self.assertTrue(all(output["signature_checks"].values()))


if __name__ == "__main__":
    unittest.main()
